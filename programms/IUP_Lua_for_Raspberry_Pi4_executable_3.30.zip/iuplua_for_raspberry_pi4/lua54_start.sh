#!/bin/bash
echo chmod u+x lua54
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/pi/iuplua_for_raspberry_pi4/iup/lib/Linux510_arm/Lua54
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/pi/iuplua_for_raspberry_pi4/iup/lib/Linux510_arm

cd /home/pi/iuplua_for_raspberry_pi4/lua54/bin
# ls 
# zeigt, dass das Verzeichnis gewechselt wurde, aber nicht permanent, was sehr gut ist.
./lua54
