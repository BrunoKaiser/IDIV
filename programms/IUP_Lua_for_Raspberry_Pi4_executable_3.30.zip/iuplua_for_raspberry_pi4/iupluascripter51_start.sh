#!/bin/bash
echo chmod u+x iupluascripter51
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/pi/iuplua_for_raspberry_pi4/iup/lib/Linux510_arm/Lua51
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/pi/iuplua_for_raspberry_pi4/iup/lib/Linux510_arm

cd /home/pi/iuplua_for_raspberry_pi4/iup/bin/Linux510_arm/Lua51
# ls 
# zeigt, dass das Verzeichnis gewechselt wurde, aber nicht permanent, was sehr gut ist.
./iupluascripter51
